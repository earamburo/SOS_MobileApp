package android.net.http;

/**
 * Stub to replace deprecated legacy AndroidHttpClient
 */
public class AndroidHttpClient {
}
