package com.code.bindu.signinregister;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.net.Uri;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import android.database.Cursor;
import android.provider.OpenableColumns;
import android.app.Activity;
import android.widget.Toast;

import java.lang.String;

public class Welcome extends AppCompatActivity {

    private static final int READ_REQUEST_CODE = 42;
    private static final int PERMISSION_REQUEST_STORAGE = 1000;

    private TextView textView2;

    protected Button button1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        button1 = (Button) findViewById(R.id.button1);
        textView2 = (TextView) findViewById(R.id.textView2);

        //This will open the file manager
        button1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // your handler code here

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                //intent.setAction(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/*");
                startActivityForResult(intent,READ_REQUEST_CODE);
            }
        });
    }


    public String readText(String input) {
        File file = new File(input);
        StringBuilder text = new StringBuilder();

        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null) {
                text.append(line);
                text.append("\n");

            }

            br.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return text.toString();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == READ_REQUEST_CODE){
            if(data!=null){
                Uri uri = data.getData();
                String path = uri.getPath();
                path = path.substring((path.indexOf(":")+1));
                Toast.makeText(this, "" + path, Toast.LENGTH_SHORT).show();



                textView2.setText(readText(path));


            }








}
}}
